# My Aesthetic Digital Portfolio

A responsive, pastel-themed personal portfolio built with HTML and CSS for GitHub Pages.

## Quick start
1. Create a public GitHub repository (for example, `my-portfolio`).
2. Upload `index.html` from this folder to the root of the repository.
3. Edit `index.html` and replace all square-bracket placeholders such as `[Your Name]`.
4. Commit your changes.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
7. Wait for GitHub Pages to publish your site.

## Add your CV
Upload your PDF to the repository root and name it `resume.pdf`, or change the link in `index.html` to match your CV's filename.

## Add your photo
Find the `avatar` section in `index.html`. Replace the 🌷 emoji with:
```html
<img src="profile.jpg" alt="Portrait of [Your Name]">
```
Then upload `profile.jpg` to the repository root.

## Update later
Edit `index.html`, commit the changes, and GitHub Pages will redeploy the site. You can also upload updated images or your CV.

## Before publishing
- Replace every placeholder with accurate information.
- Replace sample project and certificate links (`href="#"`) with real links, or remove them.
- Use only skills, awards, and experiences you genuinely have.
- Avoid publishing private details such as your home address, identity-card number, or confidential documents.
